---
## Front matter
lang: ru-RU
title: "Лабораторная работа №6"
subtitle: "Мандатное разграничение прав в Linux"
author:
    Лилия М. Пономарёва
    НПИбд-02-19\inst{1}
institute: |
	\inst{1}RUDN University, Moscow, Russian Federation
date: 2022, 19 March, Moscow, Russian Federation  

## Formatting
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
toc: false
slide_level: 2
theme: metropolis
header-includes: 
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
 - \usepackage[T2A]{fontenc}
 - \usepackage{amsmath}
aspectratio: 43
section-titles: true
---

# Цель работы

Развить навыки администрирования ОС Linux. Получить первое практическое знакомство с технологией SELinux1. Проверить работу SELinux на практике совместно с веб-сервером Apache.

# Убедилась, что SELinux работает в режиме enforcing политики targeted

![Режим SELinux](../../image/1.png){ #fig:001 width=80% height=80% }

# Запустила веб-сервер

![Проверка работы веб-сервера](../../image/2.png){ #fig:001 width=80% height=80% }

# Нашла веб-сервер Apache в списке процессов

![Список процессов](../../image/3.png){ #fig:001 width=80% height=80% }

# Текущее состояние переключателей SELinux для Apache

![Состояние переключателей SELinux](../../image/4.png){ #fig:001 width=80% height=80% }

# Статистика по политике

![Статистика SELinux](../../image/5.png){ #fig:001 width=80% height=80% }

# Тип поддиректорий в директории /var/www 

![Тип поддиректорий в директории /var/www](../../image/6.png){ #fig:001 width=80% height=80% }

# Круг пользователей с разрешением на создание файлов в /var/www/html

![Право на создание файлов](../../image/6.png){ #fig:001 width=80% height=80% }

# Создала html-файл /var/www/html/test.html

![HTML-файл /var/www/html/test.html](../../image/8.png){ #fig:001 width=80% height=80% }

# Проверила контекст созданного файла

![Контекст файла](../../image/9.png){ #fig:001 width=80% height=80% }

# Обратилась к файлу через веб-сервер

![Отображение файла test.html](../../image/10.png){ #fig:001 width=80% height=80% }

# Man httpd_selinux

![Справка man httpd_selinux](../../image/12.png){ #fig:001 width=80% height=80% }

# Изменила контекст файла /var/www/html/test.html

![Изменение контекста файла](../../image/13.png){ #fig:001 width=80% height=80% }

# Обратилась к файлу через веб-сервер

![Доступ через веб-сервер](../../image/14.png){ #fig:001 width=80% height=80% }

# Log-файлы веб-сервера Apache

![log-файл](../../image/17.png){ #fig:001 width=80% height=80% }

# Посмотрела системный лог-файл

![Системный log-файл](../../image/16.png){ #fig:001 width=80% height=80% }

# Запустила веб-сервер Apache на прослушивание ТСР-порта
81

![Включение прослушивания 81 порта](../../image/18.png){ #fig:001 width=80% height=80% }

# Добавила порт 81 в список портов

![Список портов](../../image/23.png){ #fig:001 width=80% height=80% }

# Перезапустила Apache

![Перезапуск Apache](../../image/27.png){ #fig:001 width=80% height=80% }

# Вернула контекст httpd_sys_cоntent__t

![Контекст файла](../../image/26.png){ #fig:001 width=80% height=80% }

# Обратилась к файлу через веб-сервер

![Доступ по другому порту](../../image/25.png){ #fig:001 width=80% height=80% }

# Исправила конфигурационный файл apache

![Конфигурационный файл Apache](../../image/27.png){ #fig:001 width=80% height=80% }

# Попробовала удалить привязку http_port_t к 81 порту

![Удаление порта из списка](../../image/28.png){ #fig:001 width=80% height=80% }

# Удалила файл /var/www/html/test.html

![Удаление файла](../../image/29.png){ #fig:001 width=80% height=80% }

# Вывод

Получили практическое знакомство с технологией SELinux1. Проверили работу SELinx на практике совместно с веб-сервером Apache.

